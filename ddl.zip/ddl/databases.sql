-- task 1
CREATE OR REPLACE VIEW sales_revenue_by_category_qtr AS
select category.name as film_category, sum(p.amount) as sales_revenue from category
       left join film_category fc on category.category_id = fc.category_id
       left join film f on f.film_id = fc.film_id
       left join inventory i on f.film_id = i.film_id
       left join rental r on i.inventory_id = r.inventory_id
       left join payment p on r.rental_id = p.rental_id
where p.payment_date BETWEEN (timestamp 'today' - INTERVAL '3 month')::date AND now()::date
    group by category.category_id;

-- task 2
CREATE OR REPLACE FUNCTION get_sales_revenue_by_category_qtr(current_quarter integer)
RETURNS TABLE (
    film_category text,
    sales_revenue numeric
) AS
$$
BEGIN
RETURN QUERY
SELECT
    category.name AS film_category,
    COALESCE(sum(p.amount), 0) AS sales_revenue
FROM
    category
        LEFT JOIN film_category fc ON category.category_id = fc.category_id
        LEFT JOIN film f ON f.film_id = fc.film_id
        LEFT JOIN inventory i ON f.film_id = i.film_id
        LEFT JOIN rental r ON i.inventory_id = r.inventory_id
        LEFT JOIN payment p ON r.rental_id = p.rental_id
WHERE
    p.payment_date BETWEEN (timestamp 'today' - INTERVAL '3 months')::date AND now()::date
        AND EXTRACT(quarter FROM p.payment_date) = current_quarter
GROUP BY
    category.category_id, category.name;
END;
$$
LANGUAGE plpgsql;


--task 3 
CREATE OR REPLACE FUNCTION new_movie(movie_title VARCHAR) RETURNS VOID AS $$
DECLARE
    lang_id INT;
    film_id INT;
BEGIN
 
    SELECT language_id INTO lang_id FROM language WHERE name = 'Klingon';
    
    
    SELECT COALESCE(MAX(film_id), 0) + 1 INTO film_id FROM film;
    
   
    INSERT INTO film (film_id, title, rental_rate, rental_duration, replacement_cost, release_year, language_id)
    VALUES (film_id, movie_title, 4.99, 3, 19.99, EXTRACT(YEAR FROM CURRENT_DATE), lang_id);

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Language does not exist';
    END IF;
    
END;
$$ LANGUAGE plpgsql;

Explanation:
This code defines a function called "new_movie" that takes a movie title as a parameter. It then declares two variables, lang_id and film_id, to store the language ID and the new film ID, respectively.

The function starts by finding the language ID for "Klingon" in the language table. It then generates a new unique film ID by finding the maximum film ID in the film table and incrementing it by 1.

The function then inserts a new row into the film table with the provided movie title, rental rate of 4.99, rental duration of 3 days, replacement cost of 19.99, release year as the current year, and the language ID of "Klingon". If the language doesn't exist in the language table, an exception is raised.

